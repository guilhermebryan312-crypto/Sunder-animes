package com.sunder.animes

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TomatoAccessibilityService:AccessibilityService(){
    override fun onAccessibilityEvent(event:AccessibilityEvent?) { /* A análise de tela é feita pela captura autorizada. */ }
    override fun onInterrupt() {}
    companion object {
        @Volatile private var instance:TomatoAccessibilityService?=null
        fun performNextEpisodeClick():Boolean {
            val svc=instance ?: return false
            val root=svc.rootInActiveWindow ?: return false
            return findAndClick(root)
        }
        private fun findAndClick(node:AccessibilityNodeInfo):Boolean {
            val t=node.text?.toString()?.lowercase().orEmpty()
            val d=node.contentDescription?.toString()?.lowercase().orEmpty()
            val match=listOf("próximo episódio","proximo episodio","next episode","play next").any{t.contains(it)||d.contains(it)}
            if(match && node.isEnabled && node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            for(i in 0 until node.childCount){ val child=node.getChild(i) ?: continue; if(findAndClick(child)) return true }
            return false
        }
    }
    override fun onServiceConnected(){ super.onServiceConnected(); instance=this }
    override fun onDestroy(){ instance=null; super.onDestroy() }
}

package com.sunder.animes

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("sunder", Context.MODE_PRIVATE) }
    private val features = listOf(
        "Reconhecer o Tomato" to true,
        "Detectar textos de créditos na tela" to true,
        "Avançar próximo episódio automaticamente" to false,
        "Tentar recuperar carregamentos" to false,
        "Pesquisar referências online" to true,
        "Manter tela ligada durante operação" to true
    )
    private lateinit var status: TextView
    private val captureRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val outer = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,28,28,24); setBackgroundColor(0xFFF4F6FA.toInt()) }
        outer.addView(TextView(this).apply { text="SUNDER ANIMES"; textSize=26f; setTextColor(0xFF14213D.toInt()) })
        outer.addView(TextView(this).apply { text="Configure as funções. A captura e a acessibilidade exigem autorização explícita."; textSize=13f; setTextColor(0xFF596579.toInt()); setPadding(0,8,0,14) })
        val scroll=ScrollView(this); val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        features.forEachIndexed { i,pair ->
            val cb=CheckBox(this).apply { text=pair.first; textSize=15f; isChecked=prefs.getBoolean("f$i",pair.second); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("f$i",v).apply() } }
            list.addView(cb)
        }
        scroll.addView(list); outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val perms=Button(this).apply { text="AUTORIZAR ACESSIBILIDADE"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        outer.addView(perms)
        val overlay=Button(this).apply { text="ABRIR GUI FLUTUANTE"; setOnClickListener { if(!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else startService(Intent(this@MainActivity,OverlayService::class.java)) } }
        outer.addView(overlay)
        val tomato=Button(this).apply { text="ABRIR TOMATO"; setOnClickListener { openTomato() } }; outer.addView(tomato)
        val start=Button(this).apply { text="INICIAR CAPTURA E RECONHECIMENTO"; setOnClickListener { requestCapture() } }; outer.addView(start)
        status=TextView(this).apply { text="Status: aguardando autorização"; textSize=12f; gravity=Gravity.CENTER; setPadding(0,12,0,0); setTextColor(0xFF596579.toInt()) }; outer.addView(status)
        setContentView(outer)
    }

    private fun openTomato() {
        val launch=packageManager.getLaunchIntentForPackage("com.tomatos.clientapp")
        if(launch!=null) startActivity(launch) else Toast.makeText(this,"Tomato não encontrado com esse identificador. Verifique se está instalado.",Toast.LENGTH_LONG).show()
    }
    private fun requestCapture() {
        val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(),captureRequest)
    }
    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==captureRequest && resultCode==RESULT_OK && data!=null) {
            val i=Intent(this,CaptureService::class.java).putExtra("resultCode",resultCode).putExtra("data",data)
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
            status.text="Status: captura autorizada; serviço iniciado"
        } else if(requestCode==captureRequest) status.text="Status: captura não autorizada"
    }
}

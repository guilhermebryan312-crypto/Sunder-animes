package com.sunder.animes

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService:Service(){
    private var view:View?=null
    private var wm:WindowManager?=null
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(view!=null) return START_STICKY
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,18,22,18); setBackgroundColor(0xEE14213D.toInt()) }
        box.addView(TextView(this).apply{text="SUNDER ANIMES";setTextColor(-1);textSize=17f})
        box.addView(Button(this).apply{text="ABRIR TOMATO";setOnClickListener{packageManager.getLaunchIntentForPackage("com.tomatos.clientapp")?.let{it2->it2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(it2)}}})
        box.addView(Button(this).apply{text="ABRIR APP / CONFIGURAÇÕES";setOnClickListener{val i=packageManager.getLaunchIntentForPackage(packageName);i?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);if(i!=null)startActivity(i)}})
        box.addView(Button(this).apply{text="FECHAR PAINEL";setOnClickListener{stopSelf()}})
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val p=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=20;y=120}
        view=box; wm?.addView(box,p); return START_STICKY
    }
    override fun onDestroy(){ if(view!=null) wm?.removeView(view);view=null;super.onDestroy() }
}

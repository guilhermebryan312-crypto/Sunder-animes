package com.sunder.animes

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService: Service() {
    private var projection:MediaProjection?=null
    private var virtualDisplay:VirtualDisplay?=null
    private var reader:ImageReader?=null
    private var lastAction=0L
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    override fun onBind(intent:Intent?)=null
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        createChannel(); startForeground(72,Notification.Builder(this,"sunder_capture").setContentTitle("Sunder Animes ativo").setContentText("Analisando a tela enquanto a captura estiver autorizada").setSmallIcon(android.R.drawable.ic_media_play).build())
        val code=intent?.getIntExtra("resultCode",0) ?: 0
        val data=if(Build.VERSION.SDK_INT>=33) intent?.getParcelableExtra("data",Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if(data!=null && projection==null) startCapture(code,data)
        return START_NOT_STICKY
    }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26) { val nm=getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel("sunder_capture","Sunder Animes",NotificationManager.IMPORTANCE_LOW)) } }
    private fun startCapture(code:Int,data:Intent) {
        val mgr=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection=mgr.getMediaProjection(code,data) ?: return
        val metrics=DisplayMetrics(); @Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w=metrics.widthPixels; val h=metrics.heightPixels; val density=metrics.densityDpi
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        reader?.setOnImageAvailableListener({ r ->
            val image=try { r.acquireLatestImage() } catch(_:Exception){null} ?: return@setOnImageAvailableListener
            val plane=image.planes[0]; val bitmap=android.graphics.Bitmap.createBitmap(w,h,android.graphics.Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(plane.buffer); image.close()
            val input=InputImage.fromBitmap(bitmap,0)
            recognizer.process(input).addOnSuccessListener { result ->
                val text=result.text.lowercase()
                val credits=listOf("créditos","credits","ending credits","encerramento").any{text.contains(it)}
                if(credits) getSharedPreferences("sunder",0).edit().putString("last_detection","Possíveis créditos detectados").apply()
                val next=listOf("próximo episódio","proximo episodio","next episode","play next").any{text.contains(it)}
                val auto=getSharedPreferences("sunder",0).getBoolean("f2",false)
                if(next && auto && System.currentTimeMillis()-lastAction>15000) {
                    lastAction=System.currentTimeMillis()
                    TomatoAccessibilityService.performNextEpisodeClick()
                }
            }.addOnCompleteListener { bitmap.recycle() }
        },Handler(Looper.getMainLooper()))
        virtualDisplay=projection?.createVirtualDisplay("SunderCapture",w,h,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,null)
        projection?.registerCallback(object:MediaProjection.Callback(){ override fun onStop(){ stopSelf() } },Handler(Looper.getMainLooper()))
    }
    override fun onDestroy(){ virtualDisplay?.release(); reader?.close(); projection?.stop(); recognizer.close(); super.onDestroy() }
}

#!/data/data/com.termux/files/usr/bin/bash
tmux kill-session -t sunder-animes 2>/dev/null || true
termux-wake-unlock 2>/dev/null || true
echo 'Bridge parada.'

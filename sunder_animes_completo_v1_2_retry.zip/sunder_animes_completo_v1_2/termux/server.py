#!/usr/bin/env python3
"""Sunder Animes local bridge. Runs on 127.0.0.1:8765; no remote listener."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import json, time, urllib.request, urllib.parse, threading
BASE=Path.home()/"sunder_animes"
DATA=BASE/"data"
DATA.mkdir(parents=True, exist_ok=True)
CONFIG=DATA/"config.json"
LOG=DATA/"events.jsonl"
DEFAULT={"anime":"","episode":1,"episode_minutes":23,"credits_offset_minutes":20,"auto_advance":False,"min_click_interval_seconds":25,"tomato_package":"com.tomatos.clientapp"}
def cfg():
    if not CONFIG.exists(): CONFIG.write_text(json.dumps(DEFAULT,indent=2),encoding="utf-8")
    try: return {**DEFAULT,**json.loads(CONFIG.read_text(encoding="utf-8"))}
    except Exception: return DEFAULT.copy()
def log(event,details=None):
    row={"ts":int(time.time()),"event":event,"details":details or {}}
    with LOG.open("a",encoding="utf-8") as f: f.write(json.dumps(row,ensure_ascii=False)+"\n")
def kitsu_search(q):
    url="https://kitsu.io/api/edge/anime?filter[text]="+urllib.parse.quote(q)+"&page[limit]=5"
    req=urllib.request.Request(url,headers={"User-Agent":"SunderAnimes/1.2"})
    with urllib.request.urlopen(req,timeout=8) as r: data=json.loads(r.read().decode())
    return [{"id":x.get("id"),"title":(x.get("attributes") or {}).get("canonicalTitle"),"episodeCount":(x.get("attributes") or {}).get("episodeCount"),"averageLength":(x.get("attributes") or {}).get("episodeLength"),"status":(x.get("attributes") or {}).get("status")} for x in data.get("data",[])]
class Handler(BaseHTTPRequestHandler):
    def send_json(self,obj,code=200):
        raw=json.dumps(obj,ensure_ascii=False).encode(); self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(raw))); self.send_header("Access-Control-Allow-Origin","*"); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query)
        if u.path=="/ping": return self.send_json({"ok":True,"service":"Sunder Animes bridge","version":"1.2.0","time":int(time.time())})
        if u.path=="/config": return self.send_json(cfg())
        if u.path=="/status": return self.send_json({"ok":True,"config":cfg(),"last_events":tail_events(8)})
        if u.path=="/search":
            term=(q.get("q") or [""])[0].strip()
            if not term: return self.send_json({"error":"Informe ?q=nome-do-anime"},400)
            try: return self.send_json({"results":kitsu_search(term),"source":"Kitsu API","warning":"A API não fornece o segundo exato de início dos créditos."})
            except Exception as e: return self.send_json({"error":"Pesquisa online indisponível","detail":str(e)},502)
        if u.path=="/credits-estimate":
            c=cfg(); length=max(1,int(c.get("episode_minutes",23))); offset=max(1,int(c.get("credits_offset_minutes",20)))
            return self.send_json({"kind":"estimate_not_verified","episode_minutes":length,"estimated_credits_start_minute":min(length,offset),"warning":"Estimativa configurável, não dado pesquisado nem confirmação visual."})
        if u.path=="/events": return self.send_json({"events":tail_events(50)})
        return self.send_json({"error":"not found"},404)
    def do_POST(self):
        n=int(self.headers.get("Content-Length",0));
        try: body=json.loads(self.rfile.read(n) or b"{}")
        except Exception: return self.send_json({"error":"JSON inválido"},400)
        if self.path=="/config":
            c=cfg(); c.update({k:v for k,v in body.items() if k in DEFAULT}); CONFIG.write_text(json.dumps(c,indent=2,ensure_ascii=False),encoding="utf-8"); log("config_updated",body); return self.send_json({"ok":True,"config":c})
        if self.path=="/event": log(str(body.get("event","unknown")),body.get("details")); return self.send_json({"ok":True})
        return self.send_json({"error":"not found"},404)
    def log_message(self,*args): pass
def tail_events(n):
    if not LOG.exists(): return []
    return [json.loads(x) for x in LOG.read_text(encoding="utf-8").splitlines()[-n:] if x.strip()]
if __name__=="__main__":
    CONFIG.parent.mkdir(parents=True,exist_ok=True)
    if not CONFIG.exists(): CONFIG.write_text(json.dumps(DEFAULT,indent=2),encoding="utf-8")
    print("Sunder Animes bridge: http://127.0.0.1:8765 (Ctrl+C para parar)")
    ThreadingHTTPServer(("127.0.0.1",8765),Handler).serve_forever()

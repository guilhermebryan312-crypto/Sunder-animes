#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
pkg update -y
pkg install -y python tmux curl termux-api termux-api
mkdir -p "$HOME/sunder_animes/data"
cp "$(dirname "$0")/server.py" "$HOME/sunder_animes/server.py"
cp "$(dirname "$0")/start.sh" "$HOME/sunder_animes/start.sh"
cp "$(dirname "$0")/stop.sh" "$HOME/sunder_animes/stop.sh"
cp "$(dirname "$0")/start.sh" "$HOME/sunder_animes/start.sh"
cp "$(dirname "$0")/stop.sh" "$HOME/sunder_animes/stop.sh"
[ -f "$HOME/sunder_animes/data/config.json" ] || cp "$(dirname "$0")/data/config.json" "$HOME/sunder_animes/data/config.json"
chmod +x "$HOME/sunder_animes/server.py"
echo 'Instalação concluída. Inicie com: bash ~/sunder_animes/start.sh'

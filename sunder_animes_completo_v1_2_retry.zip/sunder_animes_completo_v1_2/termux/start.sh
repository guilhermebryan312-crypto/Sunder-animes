#!/data/data/com.termux/files/usr/bin/bash
set -e
mkdir -p "$HOME/sunder_animes/logs"
cd "$HOME/sunder_animes"
if tmux has-session -t sunder-animes 2>/dev/null; then echo 'Sunder Animes já está rodando.'; else tmux new-session -d -s sunder-animes 'python server.py >> logs/bridge.log 2>&1'; fi
termux-wake-lock 2>/dev/null || true
echo 'Bridge iniciada em http://127.0.0.1:8765'
curl -fsS http://127.0.0.1:8765/ping || true

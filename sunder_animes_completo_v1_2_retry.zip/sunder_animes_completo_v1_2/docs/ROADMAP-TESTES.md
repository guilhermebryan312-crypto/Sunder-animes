# Checklist de validação real

- [ ] Actions compila o APK sem erro.
- [ ] APK instala no Galaxy A07 (Android 15).
- [ ] Botão ABRIR TOMATO encontra o pacote instalado.
- [ ] Permissão de sobreposição e GUI flutuante funcionam.
- [ ] MediaProjection inicia e mantém a captura enquanto a sessão estiver ativa.
- [ ] OCR lê texto de teste em português e inglês.
- [ ] O serviço de acessibilidade identifica o botão real do Tomato.
- [ ] Avanço automático funciona sem cliques repetidos.
- [ ] Ponte Termux responde em 127.0.0.1:8765.
- [ ] Kitsu responde à pesquisa de anime.
- [ ] Teste de tela apagada: documentar as limitações reais do Android; não assumir captura contínua.

Não habilitar avanço automático em uso contínuo antes de concluir os testes acima.

# Sunder Animes v1.2 — pacote de desenvolvimento

Este ZIP contém um projeto Android + ponte Python para Termux e workflow GitHub Actions. Não é correto prometer funcionamento integral antes de compilar e testar no aparelho e no app Tomato específico.

## O que está implementado nesta base
- Aplicativo Android com tela principal e preferências SIM/NÃO.
- Botões para abrir a GUI flutuante, pedir captura de tela e abrir o Tomato pelo pacote configurado.
- Serviço de captura MediaProjection e OCR ML Kit para identificar textos que indiquem créditos/próximo episódio.
- Serviço de Acessibilidade que tenta clicar em um controle acessível com rótulo de próximo episódio, apenas se a opção estiver ativada e a permissão tiver sido concedida.
- Serviço flutuante básico.
- Ponte Termux local (127.0.0.1:8765), com status, configuração, log, pesquisa de títulos via Kitsu e estimativa configurável de créditos.
- Workflow para compilar APK debug no GitHub Actions.

## Limites importantes
1. Pesquisa Kitsu localiza títulos e metadados gerais; não fornece o timestamp exato de créditos por episódio. `/credits-estimate` é somente estimativa configurável.
2. OCR por si só não identifica com certeza que a sequência de créditos começou. A detecção precisa ser validada com capturas reais do Tomato e pode falhar dependendo do idioma/tema.
3. Acessibilidade só consegue clicar se o Tomato expuser um nó acessível com texto/descrição compatível. Não há garantia de clique em controles desenhados em vídeo/canvas.
4. O pacote do Tomato está configurado como `com.tomatos.clientapp`, conforme a configuração fornecida no projeto. Se o app instalado tiver outro identificador, o botão não o encontrará.
5. MediaProjection requer autorização explícita e pode parar quando o Android revogar a sessão. Não há captura silenciosa.
6. `FLAG_KEEP_SCREEN_ON` só mantém a tela ligada enquanto a Activity está visível; o serviço não pode forçar brilho/tela ligada permanentemente em qualquer estado. O Android pode limitar processos em segundo plano.
7. Recuperação automática de rede específica do Tomato não está implementada porque não há API oficial/contrato do app para isso.

## GitHub Actions
1. Crie um repositório vazio no GitHub.
2. Extraia este ZIP e envie o conteúdo da pasta para a raiz do repositório (a pasta `.github` também).
3. Abra Actions → Build Sunder Animes APK → Run workflow.
4. Baixe o artifact `sunder-animes-debug-apk` após o job terminar verde.

O workflow usa Gradle instalado na máquina runner; não exige Gradle Wrapper no ZIP.

## Termux no Android
No Termux, copie a pasta `termux` do ZIP para o armazenamento compartilhado ou clone o repositório. Exemplo, se os arquivos estiverem em `~/storage/downloads/sunder_animes_completo_v1_2/termux`:

```bash
pkg update -y
pkg install -y python tmux curl
bash ~/storage/downloads/sunder_animes_completo_v1_2/termux/setup.sh
bash ~/sunder_animes/start.sh
```

Teste a ponte:

```bash
curl http://127.0.0.1:8765/ping
curl 'http://127.0.0.1:8765/search?q=Re%3AZero'
curl http://127.0.0.1:8765/credits-estimate
```

Parar:

```bash
bash ~/sunder_animes/stop.sh
```

## Permissões e primeiro uso
- Instale o APK.
- Abra o app e conceda acesso de sobreposição para a GUI flutuante quando solicitado.
- Ative o serviço de Acessibilidade nas configurações do Android se desejar permitir cliques acessíveis.
- Toque em iniciar captura e aceite a autorização de gravação/captura de tela do Android.
- Abra o Tomato pelo botão do Sunder Animes.
- Teste primeiro com avanço automático desativado; só ative após validar a identificação e o botão acessível.

## Estado de validação
- Estrutura e arquivos do projeto: empacotados.
- Build Android: deve ser validada no GitHub Actions.
- Testes no Galaxy A07 e no Tomato: pendentes.
- Pesquisa de timestamps exatos de créditos: indisponível por API pública usada nesta base.
